import { useState } from "react";
// import React from "react";
// import ReactDOM from 'react-dom/client';
import "bootstrap/dist/css/bootstrap.min.css";
import CurrencyDataService from "../services/currency";
function MyForm() {
  const [inputs, setInputs] = useState({ fromC: "USD", toC: "USD", amount: 1 });
  const [selected, setSelected] = useState("no");
  const [result, setResult] = useState(0);
  const [rate, setRate] = useState(0);
  const [apiResults, setApiResults] = useState(0);
  const api =
    "https://v6.exchangerate-api.com/v6/67a65b5730cc37f0e299eb74/pair/";
  // const response=await api.get(`${from}/${to}`)
  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setInputs((values) => ({ ...values, [name]: value }));
  };

  const onRadioClick = (event) => {
    console.log(event.target.value);
    setSelected(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (selected !== "yes") {
      // fetch(`http://localhost:8081/result?from=${inputs.fromC}&to=${inputs.toC}&amount=${inputs.amount}`)
      // .then(resp => resp.json()).then(data=>this.setResult(data))
      try {
        CurrencyDataService.getResult(
          inputs.fromC,
          inputs.toC,
          inputs.amount
        ).then((response) => {
          setResult(response.data);
        });
        CurrencyDataService.getRate(inputs.fromC, inputs.toC).then((res) => {
          setRate(res.data);
        });
        console.log("from= " + inputs.fromC);
        console.log("to= " + inputs.toC);
        console.log("amount= " + inputs.amount);
        console.log("res= " + result);
        console.log("rate= " + rate);
        //   alert(inputs.amount + "=" + result);
        return (
          <div>
            <h1>{{ rate }}</h1>
          </div>
        );
      } catch (e) {
        console.log(e);
      }
    } else {
      b(inputs.fromC, inputs.toC);

      const rate2 = apiResults;
      const res = rate2 * inputs.amount + 0;

      console.log("rate2 = " + rate2);
      console.log("apiResults" + apiResults);
      console.log("res is " + res);
      setResult(res);
      event.preventDefault();
    }
    async function b(from, to) {
      const rez = CurrencyDataService.getResultApi(from, to)
        .then(
          (res) => (
            setApiResults(res.data.conversion_rate),
            console.log("bb " + res.data.conversion_rate)
          )
        )
        .catch(console.error);
      setRate(apiResults);
      setResult(rate * inputs.amount);
      console.log("rez" + rez);
      // alert(inputs.amount);
      return rez;
    }
    console.log("r=" + result);
  };
  return (
    <div>
      {/* <form onSubmit={handleSubmit}>
      <label>Enter your name:
      <input 
        type="text" 
        name="username" 
        value={inputs.username || ""} 
        onChange={handleChange}
      />
      </label>
      <label>Enter your age:
        <input 
          type="number" 
          name="age" 
          value={inputs.age || ""} 
          onChange={handleChange}
        />
        </label>
        <input type="submit" />
    </form> */}
      <form onSubmit={handleSubmit}>
        <div
          className="form-group"
          style={{ margin_left: "5px", padding_left: "5px" }}
        >
          <label>Amount</label>
          <input
            type="number"
            min="0"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Enter Amount To Be Exchanged"
            name="amount"
            value={inputs.amount || ""}
            onChange={handleChange}
          />
        </div>

        <div className="input-group mb-3">
          <div className="input-group-prepend">
            <label className="input-group-text">From Currency</label>
          </div>
          <select
            className="custom-select"
            id="inputGroupSelect01"
            name="fromC"
            value={inputs.fromC || "USD"}
            onChange={handleChange}
          >
            <option value="USD">USD</option>
            <option value="ILS">ILS</option>
            <option value="JOD">JOD</option>
            <option value="ZWL">ZWL</option>
            <option value="TWD">TWD</option>
            <option value="SBD">SBD</option>
            <option value="QAR">QAR</option>
            <option value="HKD">HKD</option>
            <option value="EUR">EUR</option>
            <option value="AUD">AUD</option>
          </select>
        </div>
        <div className="input-group mb-3">
          <div className="input-group-prepend">
            <label className="input-group-text">To Currency</label>
          </div>
          <select
            className="custom-select"
            id="inputGroupSelect02"
            name="toC"
            value={inputs.toC || "USD"}
            onChange={handleChange}
          >
            <option value="USD">USD</option>
            <option value="ILS">ILS</option>
            <option value="JOD">JOD</option>
            <option value="ZWL">ZWL</option>
            <option value="TWD">TWD</option>
            <option value="SBD">SBD</option>
            <option value="QAR">QAR</option>
            <option value="HKD">HKD</option>
            <option value="EUR">EUR</option>
            <option value="AUD">AUD</option>
          </select>
        </div>

        <div className="form-check">
          <label>Use External API</label> <br />
          <input
            type="radio"
            id="yes"
            name="choose"
            value="yes"
            checked={selected === "yes"}
            onChange={onRadioClick}
          />
          <label>Yes</label>
          <input
            type="radio"
            id="no"
            name="choose"
            value="no"
            onChange={onRadioClick}
            checked={selected === "no"}
          />
          <label>No</label>
        </div>
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
      <div style={{ margin_left: "5px", padding_left: "5px" }}>
        <label htmlFor="rate">Rate: </label>
        <h4
          className="rate"
          style={{ margin_left: "5px", padding_left: "5px" }}
        >
          {rate}
        </h4>
        <label htmlFor="result">Result: </label>
        <h4 className="result">{result}</h4>
      </div>
      {/* <h1>{{rate}}</h1> */}
    </div>
  );
}
export default MyForm;

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<MyForm />);
// export default root;
