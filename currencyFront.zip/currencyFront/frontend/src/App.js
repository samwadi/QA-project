import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import MyForm from "./components/currencyForm";
function App() {

  return (
    <div>

       <nav className="navbar navbar-expand navbar-dark bg-dark">
        <a href="/#" className="navbar-brand"> Currency Exchange</a>
      </nav>
      <MyForm/>
    </div>
  );
}

export default App;
