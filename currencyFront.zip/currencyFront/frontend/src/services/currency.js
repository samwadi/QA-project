import http from "../http-common";
import http2 from "../http2";
class CurrencyDataService {
 
  async getResult(from, to, amount) {
    const response = await http.get(
      `result?from=${from}&to=${to}&amount=${amount}`
    );
    return response;
  }
  async getRate(from,to){
    const response=await http.get(`rate?from=${from}&to=${to}`)
    return response;
  }
  async getResultApi(from,to){
    // const [apiResults, setApiResults] = useState([]);
   
    const response=await http2.get(`${from}/${to}`)
    console.log("responce api = "
    +response)
   return response;
   

  }
 
}
export default new CurrencyDataService();
