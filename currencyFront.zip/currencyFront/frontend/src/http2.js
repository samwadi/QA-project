import axios from "axios";

export default axios.create({
  baseURL:"https://v6.exchangerate-api.com/v6/67a65b5730cc37f0e299eb74/pair/",
  //  "https://us-east-1.aws.webhooks.mongodb-realm.com/api/client/v2.0/app/restaurant-reviews-evuay/service/restaurants/incoming_webhook/",
  headers: {
    "Content-type": "application/json"
  }
});