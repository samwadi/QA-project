package com.example.currency;


import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CurrencyRest {

    private final CurrencyChangeService currencyChangeService;

    // From internet
    public CurrencyRest(CurrencyChangeService currencyChangeService) {
        this.currencyChangeService = currencyChangeService;
    }

    @GetMapping("result")
    public Float getResult(@RequestParam String from, @RequestParam String to, @RequestParam Float amount) throws Exception {
       try {
           if (from.isEmpty()||from.isBlank()||amount.isNaN()){
               throw new NullPointerException();
           }
           return currencyChangeService.getChangedAmount(amount, from.toUpperCase(), to.toUpperCase());
       }catch (Exception e){
           throw new NumberFormatException();

       }

    }
    @GetMapping("rate")
    public Float getRate(@RequestParam String from, @RequestParam String to) {
        return currencyChangeService.getRate(from, to);
    }
    @PostMapping("create")
    public void createCurrencyChange(@RequestBody CurrencyChangeRequest currencyChangeRequest) {
        currencyChangeService.createCurrencyChange(currencyChangeRequest);
    }

    @GetMapping("all")
    public List<Currency> getAllCurrencies() {
        return currencyChangeService.getAll();
    }
}
