package com.example.currency;

import java.util.Map;

public class CurrencyChangeRequest {
    private String currencyType;

    private Map<String, Float> rates;

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public Map<String, Float> getRates() {
        return rates;
    }

    public void setRates(Map<String, Float> rates) {
        this.rates = rates;
    }
}
