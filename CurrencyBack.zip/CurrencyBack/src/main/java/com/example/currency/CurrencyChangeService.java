package com.example.currency;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CurrencyChangeService {

    private final CurrencyRepository currencyRepository;

    public CurrencyChangeService(CurrencyRepository currencyRepository) {
        this.currencyRepository = currencyRepository;
    }

    public Float getChangedAmount(Float amount, String fromCurrency, String toCurrency) throws Exception {

        Float rate = getRate(fromCurrency, toCurrency);
        return currencyChange(amount, rate);
    }

    public Float getRate(String fromCurrency, String toCurrency) {
        // get from db fromCurrency by name
        Currency currency = currencyRepository.findCurrencyByName(fromCurrency);
        // get from map the toCurrency rate
        return currency.getRates().get(toCurrency);
    }

    public Float currencyChange(Float amount, Float rate) {
        return amount * rate;
    }

    public void createCurrencyChange(CurrencyChangeRequest currencyChangeRequest) {
        String currencyType = currencyChangeRequest.getCurrencyType();
        Currency currencyChangeExist = currencyRepository.findCurrencyByName(currencyType);
        Currency currency = new Currency();
        if (currencyChangeExist != null) {
            currency = currencyChangeExist;
            currency.getRates().putAll(currencyChangeRequest.getRates());
        } else {
            currency.setRates(currencyChangeRequest.getRates());
        }
        currency.setName(currencyType);

        currencyRepository.save(currency);
    }

    public List<Currency> getAll() {
        return currencyRepository.findAll();
    }
}
