package com.example.currency;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CurrencyRepository extends MongoRepository<Currency, String> {

    Currency findCurrencyByName(String currencyType);
    List<Currency> findAll();
}
