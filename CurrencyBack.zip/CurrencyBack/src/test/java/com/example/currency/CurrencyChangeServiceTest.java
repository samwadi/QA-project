package com.example.currency;

import org.assertj.core.api.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class CurrencyChangeServiceTest {

    static CurrencyChangeService currencyChangeService;
    private static CurrencyRepository currencyRepository;

    @BeforeAll
    public static void setup() {
        currencyRepository = Mockito.mock(CurrencyRepository.class);
        currencyChangeService = new CurrencyChangeService(currencyRepository);
    }

    @Test
    public void testCurrencyChange()
    {
        float result = currencyChangeService.currencyChange(5.0f, 10.0f);
        Assertions.assertEquals(50.0f, result);
    }

    @Test
    public void testGetRate()
    {
        String fromCurrency = "USD";
        String toCurrency = "ILS";
        Map<String, Float> ratesMap = new HashMap<>();
        float rate = 3.70f;
        ratesMap.put(toCurrency, rate);

        Currency currency = new Currency();
        currency.setName("USD");
        currency.setRates(ratesMap);
        Mockito.when(currencyRepository.findCurrencyByName(fromCurrency)).thenReturn(currency);

        float result = currencyChangeService.getRate(fromCurrency, toCurrency);
        Assertions.assertEquals(rate, result);
    }

    @Test
    public void testGetChangedAmount() throws Exception {
        String fromCurrency = "USD";
        String toCurrency = "ILS";
        Map<String, Float> ratesMap = new HashMap<>();
        float rate = 3.70f;
        ratesMap.put(toCurrency, rate);

        Currency currency = new Currency();
        currency.setName("USD");
        currency.setRates(ratesMap);
        Mockito.when(currencyRepository.findCurrencyByName(fromCurrency)).thenReturn(currency);

        float result = currencyChangeService.getChangedAmount(5.0f, fromCurrency, toCurrency);
        float expectedResult = rate * 5.0f;
        Assertions.assertEquals(expectedResult, result);
    }
    @DisplayName("this is a test with parameters for null errors")
    @ParameterizedTest
    @NullSource
    public void testforNullAndEmptyError(String name){
        Mockito.when(currencyRepository.findCurrencyByName(name)).thenThrow();
//        Assertions.assertThrows()

    }
    @CsvFileSource
    @Test
    public void testFromSCVFile(){

    }
}
